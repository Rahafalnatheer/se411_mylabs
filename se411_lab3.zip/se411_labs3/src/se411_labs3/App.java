package se411_labs3;
import java.util.List;

public class App {
// exercise 3
	public static void printList(List<?> list) {
	    for (Object item : list) {
	        System.out.println(item);
	    }
	}
	
	public static double sumNumbers(List<? extends Number> list) {
	    double sum = 0;

	    for (Number number : list) {
	        sum += number.doubleValue();
	    }

	    return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] names = {"waleed", "Sara", "Rahaf"};

		PrintableList<String> stringList = new PrintableList<>(names);

		stringList.printItems();
		
		Integer[] numbers = {10, 20, 30, 40};

		PrintableList<Integer> integerList = new PrintableList<>(numbers);

		integerList.printItems();

		// exercise 2 
		NumberBox<Integer> intBox = new NumberBox<>();

		intBox.setItem(10);

		System.out.println("Integer item: " + intBox.getItem());

		System.out.println("Integer sum: " + intBox.sum(20));
		NumberBox<Double> doubleBox = new NumberBox<>();

		doubleBox.setItem(10.5);

		System.out.println("Double item: " + doubleBox.getItem());

		System.out.println("Double sum: " + doubleBox.sum(5.5));
	
	// exercise 3 
		printList(stringList.getList());
		printList(integerList.getList());
		System.out.println("Sum of integers: " + sumNumbers(integerList.getList()));
	}

}
